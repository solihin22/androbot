package com.example.test1.models;

import java.util.ArrayList;

public class Matkuls {
    private ArrayList<Matkul> matkuls;

    public ArrayList<Matkul> getMatkuls() {
        return matkuls;
    }
    public void setMatkuls(ArrayList<Matkul> matkuls) {
        this.matkuls = matkuls;
    }
}
