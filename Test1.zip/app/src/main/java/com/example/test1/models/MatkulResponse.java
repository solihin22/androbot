package com.example.test1.models;

import com.google.gson.annotations.SerializedName;

public class MatkulResponse {
    @SerializedName("values")
    private Matkul values;

    public Matkul getValues() {
        return values;
    }

    public void setValues(Matkul values) {
        this.values = values;
    }
}
