package com.example.test1.models;

import com.google.gson.annotations.SerializedName;

public class StudentResponse {
    @SerializedName("values")
    private Student values;

    public StudentResponse(Student student){
        this.values = student;
    }

    public Student getStudent(){
        return values;
    }
}
