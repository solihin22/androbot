package com.example.test1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.example.test1.api.Config;
import com.example.test1.api.Service;
import com.example.test1.models.MatkulResponse;
import com.example.test1.models.StudentResponse;
import com.example.test1.storage.SharedPrefManager;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    TextView dosen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dosen = (TextView)findViewById(R.id.dosenName);
//        TextView nim_mahasiswa = (TextView)findViewById(R.id.nim_mahasiswa);

//        myAwesomeTextView.setText(SharedPrefManager.getInstance(this).getStudent().getName());
//        nim_mahasiswa.setText("nim :"+SharedPrefManager.getInstance(this).getStudent().getNim());
//        Toast.makeText(getApplicationContext(), "ini nim yang login " + SharedPrefManager.getInstance(this).getStudent().getNim(), Toast.LENGTH_LONG).show();


        // ini kodingan dari retrofit
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Config.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        Service service = retrofit.create(Service.class);

        Call<MatkulResponse> call = service.getMatkulByNim(
                SharedPrefManager.getInstance(this).getStudent().getNim()
        );

        call.enqueue(new Callback<MatkulResponse>() {
            @Override
            public void onResponse(Call<MatkulResponse> call, Response<MatkulResponse> response) {
                dosen.setText(response.body().getValues().getNama_dosen());
            }

            public void onFailure(Call<MatkulResponse> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
