package com.example.test1.api;

public class Config {
    public static final String BASE_URL = "http://172.16.16.159:8000/";
}