package com.example.test1.api;

import com.example.test1.models.MatkulResponse;
import com.example.test1.models.StudentResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface Service {
    @GET("student")
    Call<StudentResponse> getStudents();

    @GET("student/{nim}")
    Call<StudentResponse> getStudentsByNim(
            @Path("id") int id
    );

    @FormUrlEncoded
    @POST("login")
    Call<StudentResponse> login(
            @Field("nim") int nim,
            @Field("password") String password
    );

    @GET("matkul/{nim}")
    Call<MatkulResponse> getMatkulByNim (
        @Path("nim") int nim
    );
}
