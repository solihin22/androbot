package com.example.test1.models;

public class Matkul {
    int id;
    String nama_dosen;
    String matkul;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNama_dosen() {
        return nama_dosen;
    }

    public void setNama_dosen(String nama_dosen) {
        this.nama_dosen = nama_dosen;
    }

    public String getMatkul() {
        return matkul;
    }

    public void setMatkuldosenName(String matkul) {
        this.matkul = matkul;
    }
}
