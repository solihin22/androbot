package com.example.test1.storage;


import android.content.Context;
import android.content.SharedPreferences;

import com.example.test1.models.Student;

public class SharedPrefManager {
    private static SharedPrefManager mInstance;
    private static Context mCtx;

    private static final String SHARED_PREF_NAME = "data";

    private static final String KEY_CUSTOMERS_NIM = "nim";
    private static final String KEY_CUSTOMERS_NAME = "name";
    private static final String KEY_CUSTOMERS_ADDRESS = "address";

    private SharedPrefManager(Context context) {
        mCtx = context;
    }

    public static synchronized SharedPrefManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SharedPrefManager(context);
        }
        return mInstance;
    }

    public void loginStudent(Student student) {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(KEY_CUSTOMERS_NIM, student.getNim());
        editor.putString(KEY_CUSTOMERS_NAME, student.getName());
        editor.putString(KEY_CUSTOMERS_ADDRESS, student.getAddress());
        editor.clear();
        editor.apply();
    }

    public boolean isLoggedIn() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return sharedPreferences.getInt(KEY_CUSTOMERS_NIM, 0) != 0;
    }

    public Student getStudent() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        return new Student(
                sharedPreferences.getInt(KEY_CUSTOMERS_NIM, 0),
                sharedPreferences.getString(KEY_CUSTOMERS_NAME, null),
                sharedPreferences.getString(KEY_CUSTOMERS_ADDRESS, null)
        );
    }

    public boolean logout() {
        SharedPreferences sharedPreferences = mCtx.getSharedPreferences(SHARED_PREF_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        return true;
    }
}
